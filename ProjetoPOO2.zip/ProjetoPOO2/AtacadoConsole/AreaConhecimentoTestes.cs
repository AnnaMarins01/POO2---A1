using Atacado.BD.EF.Database;

namespace AtacadoConsole;

public class AreaConhecimentoTestes : BaseTestes
{
    public AreaConhecimentoTestes(AtacadoContext contexto) : base(contexto)
    {
    }

    public override void Imprimir()
    {
         Console.WriteLine("--- Exibindo Areas de Conhecimentos ---");
        foreach (AreaConhecimento item in context.AreasConhecimento)
        {
            Console.WriteLine($"{item.CodigoArea} - {item.Descricao} - {item.Situacao}");
        }
        Console.WriteLine("--- Finalizando Areas de Conhecimentos ---");
        Console.ReadLine();
    }
}
