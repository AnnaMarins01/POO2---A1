using Atacado.BD.EF.Database;

namespace AtacadoConsole;

public class CidadeTestes : BaseTestes
{
    public CidadeTestes(AtacadoContext contexto) : base(contexto)
    {
    }

    public override void Imprimir()
    {
        Console.WriteLine("--- Exibindo Cidades ---");
        foreach (Cidade item in context.Cidades)
        {
            Console.WriteLine($"{item.CodigoCidade} - {item.Nome} - {item.CodigoIBGE7} - {item.UF} - {item.CodigoEstado}");
        }
        Console.WriteLine("--- Finalizando Cidades ---");
        Console.ReadLine();
    }
}
