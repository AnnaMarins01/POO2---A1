using Atacado.BD.EF.Database;

namespace AtacadoConsole;

public class RegiaoTestes : BaseTestes
{
    public RegiaoTestes(AtacadoContext contexto) : base(contexto)
    {
    }

    public override void Imprimir()
    {
        Console.WriteLine("--- Exibindo Regioes ---");
        foreach (Regiao item in context.Regioes)
        {
            Console.WriteLine($"{item.CodigoRegiao} - {item.Nome}");
        }
        Console.WriteLine("--- Finalizando Regioes ---");
        Console.ReadLine();
    }
}
